package cardDuel.enums;

public interface enumCardDuel {

}
