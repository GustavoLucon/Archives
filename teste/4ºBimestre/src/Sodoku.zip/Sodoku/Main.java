/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Sodoku;

/**
 *
 * @author 35895842895
 */
public class Main {
        public static void main(String[] args) {
        new Campo();
        }

}
