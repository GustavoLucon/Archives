package JogoDaVelha;


public class Jogo {
	public Jogo()
	{
		new Tabela();
	}
}
