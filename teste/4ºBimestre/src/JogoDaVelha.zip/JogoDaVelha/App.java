package JogoDaVelha;

import CalcularDistanciaPontos.Ex2;

public class App {
	public static void main(String[] args)
	{
		new Jogo();
	}
}
